import 'package:stackfood_multivendor/interface/repository_interface.dart';

abstract class HomeRepositoryInterface extends RepositoryInterface {
}