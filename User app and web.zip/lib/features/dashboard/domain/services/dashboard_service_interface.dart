abstract class DashboardServiceInterface{

  bool checkDistanceForAddressPopup(double? distance);
  Future<bool> saveRegistrationSuccessful(bool status);
  Future<bool> saveIsRestaurantRegistration(bool status);
  bool getRegistrationSuccessful();
  bool getIsRestaurantRegistration();
}