enum UserType {
  user,
  customer,
  admin,
  // ignore: constant_identifier_names
  delivery_man,
  vendor,
}